# coding=utf-8
from selenium import webdriver
import requests
import re
import time
from fake_useragent import UserAgent as ua
from selenium.webdriver.chrome.options import Options
import json
import os


# 获取抖音视频
# 总结：当你确定自己获取的签名js加密是正确的时候，不要犹豫，坚信自己！有可能是接口不稳定，使用while去循环请求
# 感想：玛德，作为一名新手，一开始以为自己获取的js加密是错的，苦苦纠结了两天呢！！！后面查了下baidu，原因来接口问题。。。总之，当你js再三检查是正确的时候，基本上就是其他问题！
class DySpider:
    def __init__(self):
        self.dytk_url = "https://www.iesdouyin.com/share/user/{}"
        self.json_url = "https://www.iesdouyin.com/web/api/v2/aweme/post/?user_id={}&sec_uid=&count=21&max_cursor=0&aid=1128&_signature={}&dytk={}"
        self.headers = {}

    def get_id_list(self):
        # 获取id
        with open(r"./id.txt", 'r') as f:
            id_list = re.findall(r"\d+", f.read())
            return id_list

    def parse_url(self, url):  # 发送请求，获取响应
        self.headers["user-agent"] = ua().random
        response = requests.get(url, headers=self.headers)
        return response.content.decode()

    def get_dytk(self, html_str):  # 获取dytk（动态token）
        dytk = re.findall(r"dytk: '(.*?)'", html_str)[0] if len(re.findall(r"dytk: '.*?'", html_str)) > 0 else None
        return dytk

    def get_sign(self):  # 获取签名
        # 我的简写
        chrome_options = Options()
        chrome_options.add_argument("--headless")  # 不打开浏览器，后台运行
        abspath = os.path.abspath(r"E:\hzh\software\360\chromedriver.exe")
        driver = webdriver.Chrome(executable_path=abspath, chrome_options=chrome_options)
        driver.get(r"E:\hzh\py_project\Python-Python3爬虫实战JS加解密逆向教程\dy\Demo1\dy2.html")
        signature = driver.title
        driver.quit()

        # 大神的简写
        # chrome_options = Options()
        # chrome_options.add_argument("--headless")
        # abspath = os.path.abspath(r"E:\hzh\software\360\chromedriver.exe")
        # douyin_driver = webdriver.Chrome(executable_path=abspath, chrome_options=chrome_options)
        # douyin_driver.get("file:///E:\\hzh\\py_project\\Python-Python3爬虫实战JS加解密逆向教程\\dy\\dy2.html")
        # signature = douyin_driver.title
        # douyin_driver.quit()
        return signature

    def run(self):
        id_list = self.get_id_list()
        for id in id_list:
            # 0-1、替换dy.html中的id
            with open('./dy.html', 'r') as f:
                html = re.sub(r'_bytedAcrawler.sign\("\d+"\)', '_bytedAcrawler.sign("{}")'.format(id), f.read())

            with open('./dy2.html', 'w', encoding='utf-8') as f:
                f.write(html)

            # 0-2、获取动态token
            html_str = self.parse_url(self.dytk_url.format(id))
            dytk = self.get_dytk(html_str)

            # 1、构建url请求地址
            # 2、发送请求，获取响应
            sign = self.get_sign()

            # 接口不太稳定，所以要使用while循环一直调用（不知道大神是怎么知道）
            while True:
                json_str = self.parse_url(self.json_url.format(id, sign, dytk))
                print(json_str)
                if json.loads(json_str)["aweme_list"] == []:
                    # time.sleep(1)
                    continue
                else:
                    print("===" + json_str)
                    # 3、提取数据
                    video_list = json.loads(json_str)['aweme_list']
                    for video in video_list:
                        # 4、保存
                        video_url = video['video']['download_addr']['url_list'][0]
                        video_url = re.sub(r"aweme/v1/play/\?video_id=", r"aweme/v1/playwm/?video_id=", video_url)
                        video_name = video['author']['nickname']+video['video']['download_addr']['uri']
                        with open(video_name+".mp4", 'wb') as f:
                            video_response = requests.get(url=video_url, headers=self.headers)
                            f.write(video_response.content)


if __name__ == '__main__':
    dy = DySpider()
    dy.run()
