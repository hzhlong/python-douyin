# import coding=utf-8
import re
import requests

# 测试正则
# a = 'signc = _bytedAcrawler.sign("89923219116")'
# print(a)
# print(re.sub(r'_bytedAcrawler.sign\("\d+"\)', '_bytedAcrawler.sign("{}")'.format(333), a))


# 测试读取html
# id = 89923219116
# with open('./dy.html', 'r') as f:
#     html = re.sub(r'_bytedAcrawler.sign\(".*?"\)', '_bytedAcrawler.sign("{}")'.format(id), f.read())
#
# with open('./dy2.html', 'w', encoding='utf-8') as f:
#     f.write(html)


# 测试下载
# video_url = "https://aweme.snssdk.com/aweme/v1/play/?video_id=v0200f120000bpmbk0nm1hf71pbjbkqg&line=0&ratio=540p&media_type=4&vr_type=0&improve_bitrate=0&is_play_url=1&is_support_h265=0&source=PackSourceEnum_PUBLISH"
# video_url = re.sub(r"aweme/v1/play/\?video_id=", "aweme/v1/playwm/?video_id=", video_url)
# with open("douyin.mp4", 'wb') as f:
#     video_response = requests.get(url=video_url, headers={"user-agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"})
#     f.write(video_response.content)

